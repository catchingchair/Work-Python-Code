# Sets - they can only contain unique values. they will force uniqueness.
# Set objects are not subscriptable! they do not support indexing. 
myset = {1, 4, 0, 5, 4, 4, 2, 3}

print(myset)

