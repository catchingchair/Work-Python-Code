# tuples - they are like lists but they are immutable (an object with a fixed value, cannot be altered. numbers and strings are also immutable.)

mytuple = (0,1,2,"three")

print(mytuple[1])

x = 5639021

# print(x[1]) # this will cause an error. integers are not subscriptable. 

	

