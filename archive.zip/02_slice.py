# use slices to get parts of a sequence

mylist = [1,4,2,3,5] # make sure to use brackets not curly braces!

# the first number is the starting index
# the second number is the ending index (non-inclusive)
# the third number is the step

# syntax [start:stop:step]

print(mylist[1:4])

