print("hello world")
name = input("what is your name? ")
print(name)

